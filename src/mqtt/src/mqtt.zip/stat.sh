#!/bin/bash
curl "http://localhost:8081/mqtt/stat.js"
