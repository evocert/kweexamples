# MQTT Test

Prerequisites: curl, bash/cmd, mosquitto

Instructions:
	* deploy to /mqtt
	* kwe server assumed localhost:8081
	* mosquitto server assumed at locahost:1883, you can start mosquitto server with mosquitto.[sh|bat]
	* run test[bat|sh]

Alternatively invoke manual scripts for testing

```
connect.[bat|sh]
subscribe.[bat|sh]
monitor.[bat|sh]
publish.[bat|sh]
unmonitor.[bat|sh]
unsubscribe.[bat|sh]
disconnect.[bat|sh]
```

Observe logs, subscription hanlers in `./hdl/*.js` should invoke logging to server console to indicate their execution.
