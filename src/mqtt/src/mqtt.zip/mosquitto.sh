#!/bin/bash
mosquitto -v
